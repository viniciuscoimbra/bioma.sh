# corpo inicial mínimo (infraestrutura-como-biologia, "corpo e comportamento"):
# responde saudável e nada mais; as versões seguintes chegam pela esteira.
def principal(evento, contexto):
    return {"statusCode": 200, "body": "viva"}
